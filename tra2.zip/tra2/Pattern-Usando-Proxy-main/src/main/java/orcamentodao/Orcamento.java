package orcamentodao;

public class Orcamento {
    public void setId(long id) {
    }
}
